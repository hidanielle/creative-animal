jQuery(document).ready(function($) {

  /*
  
  // Uncomment this if you need it

  function facebook_ready() {
    FB.init({
      appId : '#FACEBOOK_APP_ID',
      channelUrl : window.location.protocol + '//' + window.location.hostname + '/channel.html',
      status : true,
      cookie : true,
      xfbml : true,
      oauth : true
    });
    FB.Canvas.setSize({height: 1200});
    FB.Canvas.scrollTo(0,0);
    FB.Canvas.setDoneLoading(function(result) {
      FB.Canvas.setAutoGrow();
    });
    window.setTimeout("FB.Canvas.setAutoGrow()", 500);
    $(document).trigger("facebook:ready");
  }

  if (window.FB) {
    facebook_ready();
  } else {
    window.fbAsyncInit = facebook_ready;
  }

  $(document).bind("facebook:ready", function(){
    // if ($("#share_container").length > 0) {
    //   share();
    // }
  });
  
  */

});
