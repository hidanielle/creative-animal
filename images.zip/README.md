## What's your creative spirit animal?

"What's Your 2015 Creative Spirit Animal" was an internal project conceptualized, designed, and developed by a group of colleagues on our Creative department. The purpose of the short quiz microsite was to show off our talents to other departments within our organization.
 
The illustrations and designs were done completely in house, and the front end development was done by myself using CSS3 animations and a jQuery back end for the quiz logic. This was my first time working so in-depth with CSS3 keyframe animations and am extremely proud of the outcome.
 
The site is fully responsive and works on all modern browsers, as far as IE10

**This is a repurposed version of the original site for demonstration purposes only and may not work exactly as intended!**